# Patna-Car-Rental
Online Car Rental Management System (WebApplication)

This is a Web based Application developed using PHP as a Host Language. Database for the Application is in [Database](https://github.com/roshan139154/Patna-Car-Rental/tree/master/Database) folder. It can be imported to your localhost(phpMyAdmin) or any other servers. Also configure the [connection.php](https://github.com/roshan139154/Patna-Car-Rental/blob/master/connection.php) to set up the necessary connections with the database.
